Ultimately I decided to pivot off of one of my 3 original managers I was planning on making.  As I was creating the resource manager, I was getting the distinct feeling that it wasn't a
good manager to use for my milestone.  I had already pushed it off to be the last manager I made, because it was the one I was the least enthused about, and that feeling didn't improve as I
worked on it.  It felt far more game than engine and wasn't very in-depth.  As a result, I decided to shift my focus onto something that made a little more sense to be handled engine-side:
Terrain Generation.  In the case of my strategy engine, something that could generate a hex grid, take in an entity and use it's position on a screen to place it into a grid.
The grid can handle either the user telling it where to put an entitiy directly, or a relative translation.  As I made this pivot relatively late in my milestone there was one feature I had 
brainstormed which I didn't get to implement, which was taking in a list of obstacles to be randomly scattered throughout the map on generation.  However even without this I feel that the 
grid is equal in value of the resource manager.
#include "Camera.h"
Camera::Camera(XMFLOAT3 position, XMFLOAT3 orientation, float aspect, float FOV) {
	transform = Transform(position, orientation, XMFLOAT3(1.0f, 1.0f, 1.0f));
	this->FOV = FOV;
	this->nearClip = 0.01f;
	this->farClip = 500.0f;
	this->moveSpeed = 3.0f;
	this->lookSpeed = 0.025f;

	eventHandler = EventHandler::GetInstance();
	UpdateViewMatrix();
	UpdateProjectionMatrix(aspect);
	eventHandler->BindEvent(M1Down, &Camera::OnClick, this);
	eventHandler->BindEvent(M1Hold, &Camera::OnDrag, this);
}

Camera::Camera(XMFLOAT3 position, XMFLOAT3 orientation, float aspect, float FOV, float nearClip, float farClip, float moveSpeed, float lookSpeed) {
	transform = Transform(position, orientation, XMFLOAT3(1.0f, 1.0f, 1.0f));
	this->FOV = FOV;
	this->nearClip = nearClip;
	this->farClip = farClip;
	this->moveSpeed = moveSpeed;
	this->lookSpeed = lookSpeed;

	UpdateViewMatrix();
	UpdateProjectionMatrix(aspect);
}

Camera::~Camera() {

}

void Camera::UpdateViewMatrix() {
	XMVECTOR position = XMVectorSet(transform.GetPosition().x, transform.GetPosition().y, transform.GetPosition().z,0.0f);

	//Get camera forward
	XMVECTOR absolute = XMVectorSet(0, 0, 1, 0.0f);
	XMVECTOR rotation = XMQuaternionRotationRollPitchYaw(transform.GetPitchYawRoll().x, transform.GetPitchYawRoll().y, transform.GetPitchYawRoll().z);
	XMVECTOR rotated = XMVector3Rotate(absolute, rotation);

	XMVECTOR up = XMVectorSet(0.0f,1.0f,0.0f,0.0f);
	XMMATRIX view = XMMatrixLookToLH(position, rotated, up);
	XMStoreFloat4x4(&M4_view, view);
}

void Camera::UpdateProjectionMatrix(float aspect) {
	XMMATRIX projection = XMMatrixPerspectiveFovLH(FOV, aspect, nearClip, farClip);
	XMStoreFloat4x4(&M4_projection, projection);
}

Transform Camera::GetTransform() {
	return transform;
}

void Camera::Update(float dt, HWND windowHandle) {
	float currentSpeed = moveSpeed;//Rather than writing 2 seperate sets of if statements, changing the speed based on if shift is pressed...

	wh = windowHandle;

	//Keyboard input
	if (GetAsyncKeyState('W') & 0x8000) { transform.MoveAbsolute(0, currentSpeed * dt, 0); }
	else if (GetAsyncKeyState('S') & 0x8000) { transform.MoveAbsolute(0, -currentSpeed * dt, 0); }
	if (GetAsyncKeyState('A') & 0x8000) { transform.MoveRelative(-currentSpeed * dt,0,0); }
	else if (GetAsyncKeyState('D') & 0x8000) { transform.MoveRelative(currentSpeed * dt,0,0); }
	if (GetAsyncKeyState(VK_SPACE) & 0x8000) { transform.MoveAbsolute(0, currentSpeed * dt, 0); }
	else if (GetAsyncKeyState('X') & 0x8000) { transform.MoveAbsolute(0, -currentSpeed * dt, 0); }
}

//Set mouse position to wherever the user clicked
bool Camera::OnClick() {
	//Mouse position
	POINT mousePos = {};
	GetCursorPos(&mousePos);	
	ScreenToClient(wh, &mousePos);

	P_lastPos = mousePos;
	return true;
}

bool Camera::OnDrag() {
	//Mouse position
	POINT mousePos = {};
	GetCursorPos(&mousePos);
	ScreenToClient(wh, &mousePos);

	float x = (P_lastPos.x - mousePos.x) * lookSpeed;
	float y = -(P_lastPos.y - mousePos.y) * lookSpeed;
	transform.MoveAbsolute(x, y, 0);

	P_lastPos = mousePos;
	UpdateViewMatrix();
	return true;
}
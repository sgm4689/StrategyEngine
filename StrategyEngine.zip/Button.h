#pragma once
#include "Transform.h"
#include "Mesh.h"
#include "Material.h"
class Button
{
	typedef void (*func_t)();
public:
	Button(Mesh*, Material*, func_t onClick);
	Button(Mesh*, Material*, float x, float y, func_t onPress);
	Mesh* GetMesh();
	Transform* GetTransform();
	Material* GetMaterial();
	void Update(float dt, HWND windowHandle);

private:
	Transform transform;
	Mesh* mesh;
	Material* material;
	func_t onPress;

	void OnClick();
};


#include "Button.h"

Button::Button(Mesh* mesh, Material* material, func_t onPress) {
	this->mesh = mesh;
	this->material = material;
	this->onPress = onPress;
	transform = Transform();
}

Button::Button(Mesh* mesh, Material* material, float x, float y, func_t onPress) {
	this->mesh = mesh;
	this->material = material;
	transform = Transform(XMFLOAT3(x,y,0), XMFLOAT3(0,0,0), XMFLOAT3(1,1,1));
	this->onPress = onPress;
}

Mesh* Button::GetMesh() {
	return mesh;
}

Transform* Button::GetTransform() {
	return &transform;
}

Material* Button::GetMaterial() {
	return material;
}

void Button::Update(float dt, HWND windowHandle) {
	//Mouse position
	POINT mousePos = {};
	GetCursorPos(&mousePos);
	ScreenToClient(windowHandle, &mousePos);

	//Mouse Input
	if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) {
		//if (transform.position.x > mousePos.x && transform.position.x + transform.width < mousePos.x)/*NOTE, actually impliment width*/
		OnClick();
	}

}

void Button::OnClick() {
	onPress();
}